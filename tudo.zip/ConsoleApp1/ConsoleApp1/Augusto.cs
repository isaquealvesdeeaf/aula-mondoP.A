﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Augusto
    {
        private int[] inteiros = new int[4];
        private int cont = 0; 
        public Augusto()
        {
        }

        public Augusto(int[] inteiros)
        {
            Inteiros = inteiros;
        }

        public int[] Inteiros { get => inteiros; set => inteiros = value; }

        public void CadastraNumero(int i)
        {
            Inteiros[cont] = i;
            cont++;
        }
        public void MostraValor()
        {
            for (int i = 0;i<Inteiros.Length;i++)
            {
                Console.WriteLine("O {0} Numero é {1}", (i + 1), Inteiros[i]);
            }
        } 
        public void Multiplicar(int n)
        {

            for (int i = 0; i < Inteiros.Length; i++)
            {
                Console.WriteLine("O resultado do  {0} Numero é {1}", (i + 1), (Inteiros[i] *n ));
            }
        }
    }
}
