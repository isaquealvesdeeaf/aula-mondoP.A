﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Augusto augusto = new Augusto();

            Console.WriteLine("Digite o primeiro Numero: ");
            augusto.CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o segundo Numero: ");
            augusto.CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o terceiro Numero: ");
            augusto.CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o quarto Numero: ");
            augusto.CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("-------------------------- ");
            augusto.MostraValor();

            Console.WriteLine("Digite um Numero inteiro: ");
            Console.WriteLine("-------------------------- ");
            augusto.Multiplicar(int.Parse(Console.ReadLine()));

            
            Console.ReadKey();
        }
    }
}
