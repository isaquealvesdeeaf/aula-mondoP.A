﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace augusto2
{
    class Program
    {
        static int cont = 0;

        static int[] Inteiros = new int[4];
        static void Main(string[] args)
        {
            

            Console.WriteLine("Digite o primeiro Numero: ");
            CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o segundo Numero: ");
            CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o terceiro Numero: ");
            CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o quarto Numero: ");
            CadastraNumero(int.Parse(Console.ReadLine()));

            Console.WriteLine("-------------------------- ");
            Mostrar();
            Console.WriteLine("-------------------------- ");

            Console.WriteLine("Digite um Numero inteiro: ");
           
            Multiplicar(int.Parse(Console.ReadLine()));


            Console.ReadKey();
        }

        public static void Mostrar()
        {
            for (int i = 0; i < Inteiros.Length; i++)
            {
                Console.WriteLine("O {0} Numero é {1}", (i + 1), Inteiros[i]);
            }

        }
        static public void Multiplicar(int n)
        {

            for (int i = 0; i < Inteiros.Length; i++)
            {
                Console.WriteLine("O resultado do  {0} Numero é {1}", (i + 1), (Inteiros[i] * n));
            }
        }
        static public void CadastraNumero(int i)
        {
            Inteiros[cont] = i;
            cont++;
        }
    }
}
